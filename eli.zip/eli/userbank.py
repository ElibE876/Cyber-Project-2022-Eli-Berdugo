from operator import contains
import base64
import os
from traceback import format_list
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC


user_list = []



def decrypte_file(key,path):
    
    f = Fernet(key)
    with open(path, "r") as file:
        encrypted_data = file.read()
    
    for encrypted_line in encrypted_data.splitlines():
        user = encrypted_line.split(",")
        if len(user) == 2: # valid user
            user_list.append([decrypt_string(f,user[0]),decrypt_string(f,user[1])])
    print("LOADED USERS: ", end = '')
    print(user_list)
    

def decrypt_string(key : Fernet,s):
    return key.decrypt(s.encode()).decode()

def encrypt_string(key : Fernet, s):
    word = key.encrypt(s.encode())
    return word

def add_user(name,password):
    if not validate_user(name,password):
        user_list.append([name,password])    
    else:
        print("user: " + name + " already exists")
    
def update_database(path,key):
    with open(path, "wb") as file:
        for user in user_list:
            #print(user)
            f = Fernet(key)
            file.write(encrypt_string(f,user[0]))
            file.write(b',')
            file.write(encrypt_string(f,user[1]))
            file.write(b'\n')

def validate_user(name,password):
    if contains(name,',') or contains(password,','):
        print("Invalid name or password")
        return
    else:
        for user in user_list:
            if user[0] == name and user[1] == password:
                return True
        return False
        


def write_key(key):
    with open("key.key","wb") as key_file:
        key_file.write(key)

def load_key():
    return open("key.key","rb").read()

def handle_database():

    path = "data.dt"

    key = load_key()

    decrypte_file(key,"data.dt")
    print("\n\n=====================\n\n")
    add_user("eli","bruh123")
    add_user("gilad","bigchungos69")
    add_user("nathan","notfunny420")
    print(validate_user("nathan","notfunny420"))
    
    key = Fernet.generate_key()
    update_database(path,key)
    write_key(key)

handle_database()